from django.contrib import admin
from reviews.models import *
admin.site.register(Review)
# Register your models here.
