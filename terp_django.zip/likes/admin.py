from django.contrib import admin

from likes.models import *
admin.site.register(Like)