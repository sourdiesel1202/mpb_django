from django.contrib import admin
from strains.models import *
admin.site.register(Strain)
# Register your models here.
