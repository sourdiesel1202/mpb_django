from django.apps import AppConfig


class TerpenesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'terpenes'
