from django.contrib import admin
from terpenes.models import *
admin.site.register(Aroma)
admin.site.register(Effect)
admin.site.register(Terpene)
admin.site.register(TerpeneProfile)
# Register your models here.
