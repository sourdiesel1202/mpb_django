from django.contrib import admin
from users.models import *
admin.site.register(UserAchievement)
admin.site.register(User)
# Register your models here.
