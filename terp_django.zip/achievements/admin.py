from django.contrib import admin
from achievements.models import *
admin.site.register(Achievement)
# admin.site.register()
# Register your models here.
