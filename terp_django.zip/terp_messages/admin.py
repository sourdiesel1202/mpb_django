from django.contrib import admin
from terp_messages.models import *
admin.site.register(Message)
admin.site.register(MessageThread)
# Register your models here.
